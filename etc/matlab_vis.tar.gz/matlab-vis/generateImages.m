function generateImages(inputDir, outputDir)
mkdir(outputDir);
allMidis = dir(strcat(inputDir,'/*.mid'));
for i = size(allMidis)
  file = allMidis(i);
  disp(['processing ', file.name]);
  midi = readmidi(strcat(inputDir,'/',file.name));
  Notes = midiInfo(midi,0);
  %% compute piano-roll:
  [PR,t,nn] = piano_roll(Notes);

  %% display piano-roll:
  figure;
  imagesc(t,nn,PR);
  axis xy;
  xlabel('time (sec)');
  ylabel('note number');

  %% also, can do piano-roll showing velocity:
  [PR,t,nn] = piano_roll(Notes,1);

  h=figure;
  imagesc(t,nn,PR);
  axis xy;
  xlabel('time (sec)');
  ylabel('note number');
  % save image
  [~,fname,~] = fileparts(file.name);
  saveas(h,strcat(outputDir,'/',fname),'jpg');
end
